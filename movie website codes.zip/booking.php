<html>
<head>
<title>BOOKING</title>
</head>
<body>
<style> 
body {
  
  background-color: #eeff99 ;
}
</style>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Movies";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$totalprice=1;
$nt=$_GET['Tickets'];
$title=$_GET['Title'];
$sql = "SELECT Price FROM MoviePrices WHERE Title='$title'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$r=implode("",$row);
$p=intval($r);
$totalprice=($p*$nt);
echo "<table cellpadding='15' border='0' bgcolor='#eccc99'>";
echo "<tr><td>Dear<b>". $_GET['customer']."</b>,<br></td></tr>";
echo "<tr><td> You have booked<b> ".$_GET['Tickets']."</b>tickets<br></td></tr>";
echo "<tr><td>for movie: <b> ".$_GET['Title']."</b><br></td></tr>";
echo "<tr><td>timing for which is<b>". $_GET['radio']." </b></td></tr>";
echo "<tr><td>Price per ticket: ".$p."</td></tr>";
echo "<br>";
echo "<tr><td>Total price to be paid is Rs <b><i> ".$totalprice."</i></b><br></td></tr>";
echo "</table>";
mysqli_close($conn);
?>
</body>
</html>