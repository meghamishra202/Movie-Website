<!DOCTYPE html>
<html>
<body>
<div id="menubar" >
<a href="home.php">Home</a>

<a href="login.php">AdminLogin</a>

<a href="bookticket.php">BookYourTicket</a>


</div> 
<style>
body
{
background-color: #ccff99 ;
}
</style>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Movies";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT Title, ReleaseDate, Description, Price FROM MoviePrices";
$result = $conn->query($sql);
echo "<table border='1'>";
echo "<tr>";
echo "<th>Title</th><th>ReleaseDate</th><th>Description</th><th>Price</th><th>Edit</th><th>Delete</th>";
echo "</tr>";
if($result)
{
while($data = mysqli_fetch_array($result))
{
echo "<tr>"; 
echo '<td>'.$data['Title'].'</td><td>'.$data['ReleaseDate'].'</td><td>'.$data['Description'].'</td><td>'.$data['Price'].'</td><td><a href="last.php?id='.$data['Title'].'">Edit</a></td><td><a href="delete.php?id='.$data['Title'].'">Delete</a></td>'; 
echo "</tr>";
}
}
 else {
    echo "0 results";
}
echo "</table>"; 
$conn->close();
?> 
<form action='' method='post'>
<input name="submit" type="submit" value="edit">
</form>
<?php
if(isset($_POST["submit"]))
{
header("Location: aaa.php");
}
?>

</body>
</html>


