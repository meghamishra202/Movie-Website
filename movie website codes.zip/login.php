<html>
<head><title> ADMIN LOGIN</title></head>
<style>
<body>
body
{
background-color:#ccff99;
}
</style>
<h2>
<table border="0" cellpadding="5" cellspacing="5" bgcolor="#ff3366">
<th colspan="2" align="center">Login</th>
<form action="" method="post">
<div class="container">
  <tr><td><label for="uname"><b>Username</b><br></label></td>
  <td ><input type="text" placeholder="Enter Username" name="uname" required></td></tr>

   <tr><td> <label for="psw"><b><br><br>Password</b><br></label> </td>
   <td><input type="password" placeholder="Enter Password" name="psw" required></td></tr>
  <tr> <td><button name="login" type="submit"><br>Login</button></td></tr>
   <tr><td> <label>
    <input type="checkbox" checked="checked" name="remember"> Remember me
    </label></td></tr>
    <tr><td><button type="button" name="cancel" class="cancelbtn">Cancel</button></td></tr>
</div>
</form> 
</table>

<?php
if(isset($_POST["login"]))
{
if( ($_POST["uname"]=="admin") && ($_POST["psw"]=="admin"))
{
header("Location: insert.php");
}
else
{
echo "Unauthorized access";
}
}
else if(isset($_POST["cancel"]))
{
header("Loaction: home.php");
}


 
?>

</form> </h2>
</body>
</html>








