<!DOCTYPE html>
<html>
<head>
<style> 
body {
  background-color: #ccff99;
}
</style>
<center>
<div id="header" ><b><font size='10' face='arial' color='red'>BookYourShow</font></b></div>
</head>
<body>
<div id="menubar" >
<a href="home.php">Home</a>

<a href="login.php">AdminLogin</a>

<a href="bookticket.php">BookYourTicket</a>


</div> 
</center>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>
</head>
<body>

<h2> </h2>

<div class="row">
  <div class="column" style="background-color:#cccf99;">
    <h2>ABOUT</h2>
    <p><i> This is an online movie ticket booking website for MovieTime, Delhi.
You can book you show in advance online and avoid long queues for getting tickets.
Enjoy Your Movie!</i> </p>
  </div>
  <div class="column" style="background-color:#fdf699;">
    <h2>NEW ARRIVALS</h2>
<?php
	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Movies";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT Title, ReleaseDate FROM MoviePrices ORDER BY ReleaseDate LIMIT 3";
$result = $conn->query($sql);

    
    while($row = $result->fetch_assoc()) {
        echo "<br> ". $row["Title"]. " - ". $row["ReleaseDate"]. "<br>";
    }

$conn->close();
?>

        <img src="images/posterbg.png" />
    
  </div>
</div>
</body>
</html>