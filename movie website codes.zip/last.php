<html>
<style>
body
{
background-color=#ccff99;
}
</style>
<?php
$id=$_GET['id'];
echo "<form action='' method='post'>";
echo "<label> Enter Title Of the Movie you want to edit: </label>";
echo "<input type='text' name='title' value='".$id."' >";
echo "<label>New ReleaseDate:</label> ";
echo "<input type='date' name='date' value=''>";
echo "<label>New Description:</label>";
echo "<input type='text' name='desc' value=''>";
echo "<label>New Price: </label>";
echo "<input type='text' name='price' value='' >";
echo "<input type='submit' name='update' value='update' >";
echo "</form>";

$servername="localhost";
$username="root";
$password="";
$dB="Movies";

$con=mysqli_connect($servername,$username,$password,$dB);

if(isset($_POST['update']))
{
$title=$_POST['title'];
$nt=$_POST['newt'];
$date=$_POST['date'];
$desc=$_POST['desc'];
$price=$_POST['price'];

$query = "UPDATE MoviePrices SET Title='$title',ReleaseDate='$date',Description='$desc',Price='$price' WHERE Title='".$id."'"; 
$result = mysqli_query($con,$query);

if($result)
{
header("Location: movie.php");
} 
else
{
echo "Query Failed";
}
}
mysqli_close($con);
?>
</html>