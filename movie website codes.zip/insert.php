
<!DOCTYPE html>
<html>
<body>
<?php
include "movie.php";
?>
<style> 
body {
  background-color: #ccff99;
}
</style>

<br>

<form action="" method="post">
<table border="0" cellpadding="10" bgcolor="#fff366">
<th>ADD MOVIES<th>
<tr><td><label>Enter Title</label>
<input name="title" type="text"></td></tr>
<tr><td><label> Enter Release Date</label>
<input name="ReleaseDate" type="date"></td></tr>
<tr><td><label>Enter description</label>
<input name="Description" type="text"></td></tr>
<tr><td><label>Enter Price</label>
<input name="Price" type="text" value=""></td></tr>

<center><tr><td><input name="submit" type="submit" value="submit"></td></tr></center>
</table>
</form>

</body>
</html>

<?php
$servername="localhost";
$username="root";
$password="";
$db="Movies";

$connect=new mysqli($servername,$username,$password,$db);

if($connect->connect_error){
die("connection failed".$connect_error);
}
echo 'connected successfully';


if(isset($_POST["submit"])){
$title=$_POST["title"];
$RD=$_POST["ReleaseDate"];
$desc=$_POST["Description"];
$price=$_POST["Price"];
if($title!='' || $price!='' )
{
$query="INSERT INTO MoviePrices(Title,ReleaseDate,Description,Price) VALUES('$title','$RD','$desc','$price')";
$result=mysqli_query($connect,$query);
header("Location: movie.php");
}
}

mysqli_close($connect);
?>


