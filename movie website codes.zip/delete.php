<?php
$servername="localhost";
$username="root";
$password="";
$dB="Movies";

$con=mysqli_connect($servername,$username,$password,$dB);
$id=$_GET['id'];
$query = "DELETE FROM MoviePrices WHERE Title='".$id."'"; 
$result = mysqli_query($con,$query);

if($result)
{
header("Location: movie.php");
} 
else
{
echo "Query Failed";
}
mysqli_close($con);
?>