<!DOCTYPE HTML>
<html>
<head>
  <title>BOOK YOUR TICKETS</title>
</head>
<body>
<style> 
body {
  background-color: #ccff99;
}
</style>

<h1> BOOK YOUR TICKETS </h1>
<div id="menubar" >
<a href="home.php">Home</a>

<a href="login.php">AdminLogin</a>

<a href="bookticket.php">BookYourTicket</a>
 <form action="booking.php" method="GET">
  <table>
<tr>
    <td> Select Your Movie</td>
     <td style="text-align:center"></td>
<td>
<?php
$server="localhost";
$user="root";
$pass="";
$db="Movies";

$connect= mysqli_connect($server,$user,$pass,$db);

$sql = "SELECT Title FROM MoviePrices";
$result = mysqli_query($connect,$sql);

echo "<select name='Title' style='width: 100px;'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['Title'] ."'>'".$row['Title']."'</option>";
}
echo "</select>";
mysqli_close($connect);
?>
</td>
</tr>

   <tr>
    <td>Name :</td>

<td  style="text-align:center"> </td>
   <br> <td><input name="customer" type="text" required></td>
   </tr>
 

<tr>
    <td>Select your Timing :</td>
    <td  style="text-align:center"></td>
<td>
   
   <br>  <input type="radio" name="radio" value="9:00 AM" >9:00 AM
    <br> <input type="radio" name="radio" value="12:00 NOON" >12:00 NOON
<br><input type="radio" name="radio" value="3:00 PM" >3:00 PM
<br><input type="radio" name="radio" value="7:00 PM" >7:00 PM
    </td>
   </tr>
   <tr>
    <td>No. of Tickets :</td>
 <td style="text-align:center"> </td>
    <td>
<br>
<select name="Tickets" required>
      <option selected hidden value="">Select a Number</option>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
     </select> 
</td>
   </tr>
    <td>Email :</td>

<td  style="text-align:center"> </td>
<br><td><input type="email" name="email" required></td>
   </tr> 
   <tr>
    <td>Phone no :</td>

<td  style="text-align:center"> </td>
    <td>
 <strong>    <br><input type="phone" name="phone" required><br></strong>
    </td>
   </tr>
   <tr>
<br>
<td  style="text-align:center"> </td>
    <br><td><input type="submit" value="submit"></td>
   </tr>
  </table>
 </form>

</body>
</html>
